<?php
session_start();
include('db.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $full_name = $_POST['full_name'];  
    $birthdate = $_POST['birthdate'];  

    // Validasi input
    if (empty($username) || empty($email) ||   empty($password) || empty($full_name) ||   empty($birthdate)) {
        echo "Semua kolom harus diisi!";
        exit();
    }

    // Hash password untuk keamanan
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Simpan data pengguna ke dalam database
    $sql = "INSERT INTO users (username, email, password, full_name, birthdate) 
            VALUES ('$username', '$email', '$hashed_password', '$full_name', '$birthdate')";

    if ($conn->query($sql) === TRUE) {
        // Jika berhasil, beri notifikasi dan redirect
        $_SESSION['register_success'] = true;
        header("Location: register.php"); // Redirect ke halaman yang sama
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();  // Menutup koneksi database
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi</title>
    <link rel="stylesheet" href="assets/css/style-register.css">
</head>
<body>

    <div class="register-container">
        <h3>Form Registrasi</h3>
        <form method="POST" action="register.php">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required><br>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required><br>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required><br>

            <label for="full_name">Nama Lengkap:</label>
            <input type="text" id="full_name" name="full_name" required><br>

            <label for="birthdate">Tanggal Lahir:</label>
            <input type="date" id="birthdate" name="birthdate" required><br>

            <button type="submit">Registrasi</button>
        </form>
    </div>

    <!-- Toast Notification -->
    <?php if (isset($_SESSION['register_success']) && $_SESSION['register_success'] == true): ?>
        <div class="toast show" id="toast">
            Anda sudah berhasil registrasi
        </div>
        <?php unset($_SESSION['register_success']); ?>
    <?php endif; ?>

    <script>
        // Menunggu beberapa detik setelah halaman dimuat
        window.onload = function() {
            if (document.getElementById("toast")) {
                setTimeout(function() {
                    document.getElementById("toast").classList.remove("show");
                    window.location.href = "login.php"; // Redirect ke halaman login
                }, 3000); // Toast akan muncul selama 3 detik
            }
        };
    </script>

</body>
</html>
