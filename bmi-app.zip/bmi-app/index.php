<?php
session_start();
include('db.php');

// Pastikan pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Proses perhitungan jika form dikirimkan
$bmi = null;
$category = null;
$error = null;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $height = $_POST['height'];
    $weight = $_POST['weight'];

    // Validasi input
    if (!empty($height) && !empty($weight) && is_numeric($height) && is_numeric($weight)) {
        // Konversi tinggi badan dari cm ke meter jika > 10
        if ($height > 10) {
            $height /= 100;
        }

        // Hitung BMI
        $bmi = $weight / ($height * $height);

        // Tentukan kategori BMI
        if ($bmi < 18.5) {
            $category = "Underweight";
        } elseif ($bmi >= 18.5 && $bmi <= 24.9) {
            $category = "Normal";
        } elseif ($bmi >= 25 && $bmi <= 29.9) {
            $category = "Overweight";
        } elseif ($bmi >= 30 && $bmi <= 34.9) {
            $category = "Obese";
        } else {
            $category = "Extremely Obese";
        }
    } else {
        $error = "Tinggi dan berat badan harus diisi dengan angka yang valid!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Body Mass Index (BMI) Calculator</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <h2>Halo, 
                <?php 
                echo isset($_SESSION['full_name']) ? htmlspecialchars($_SESSION['full_name']) : 'Pengguna'; 
                ?>
            </h2>

            <p>Selamat datang di dashboard BMI</p>
            <ul>
                <!-- Dashboard (Tidak kemana-mana) -->
                <li><a href="#">Dashboard</a></li>

                <!-- Logout (Menuju ke logout.php) -->
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
        <!-- Main Content -->
        <div class="main-content">
            <h3>Perhitungan BMI</h3>
            <div class="content-wrapper">
                <!-- Kalkulator BMI -->
                <div class="bmi-calculator">
                    <form method="POST" action="">
                        <label for="height">Tinggi Badan (meter atau cm):</label>
                        <input type="text" id="height" name="height" placeholder="Contoh: 170 atau 1.70" 
                               value="<?php echo htmlspecialchars($_POST['height'] ?? ''); ?>" required><br>

                        <label for="weight">Berat Badan (kg):</label>
                        <input type="text" id="weight" name="weight" placeholder="Contoh: 65" 
                               value="<?php echo htmlspecialchars($_POST['weight'] ?? ''); ?>" required><br><br>

                        <button type="submit">Hitung BMI</button>
                    </form>

                    <!-- Menampilkan hasil -->
                    <?php if ($error): ?>
                        <div class="error"><?php echo $error; ?></div>
                    <?php elseif ($bmi !== null): ?>
                        <div class="result">
                            <h4>Hasil Perhitungan BMI Anda:</h4>
                            <p>BMI: <?php echo number_format($bmi, 2); ?></p>
                            <p>Kategori: <?php echo $category; ?></p>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Tips Sehat -->
                <div class="tips">
                    <h3>Tips Sehat:</h3>
                    <ul>
                        <li>Konsumsi makanan bergizi seimbang setiap hari.</li>
                        <li>Luangkan waktu minimal 30 menit untuk olahraga ringan.</li>
                        <li>Cukupi kebutuhan tidur agar tubuh tetap fit.</li>
                        <li>Perbanyak minum air putih untuk menjaga hidrasi tubuh.</li>
                        <li>Periksakan kesehatan secara rutin untuk mencegah penyakit.</li>
                    </ul>

                </div>
            </div>
        </div>
    </div>
</body>
</html>
